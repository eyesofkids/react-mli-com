"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { PieChart, Users } from "lucide-react"

export function StaffPerformanceMetrics() {
  const gradeDistribution = [
    { grade: "A", count: 2, percentage: 40, color: "bg-green-500" },
    { grade: "B", count: 2, percentage: 40, color: "bg-blue-500" },
    { grade: "C", count: 1, percentage: 20, color: "bg-amber-500" },
    { grade: "D", count: 0, percentage: 0, color: "bg-red-500" },
  ]

  const getGradeBadge = (grade) => {
    switch (grade) {
      case "A":
        return (
          <Badge variant="outline" className="text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400">
            A 級
          </Badge>
        )
      case "B":
        return (
          <Badge variant="outline" className="text-blue-600 bg-blue-50 dark:bg-blue-950 dark:text-blue-400">
            B 級
          </Badge>
        )
      case "C":
        return (
          <Badge variant="outline" className="text-amber-600 bg-amber-50 dark:bg-amber-950 dark:text-amber-400">
            C 級
          </Badge>
        )
      case "D":
        return (
          <Badge variant="outline" className="text-red-600 bg-red-50 dark:bg-red-950 dark:text-red-400">
            D 級
          </Badge>
        )
      default:
        return grade
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">績效分佈</h3>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <PieChart className="h-4 w-4" />
          等級分佈
        </div>
      </div>
      <div className="space-y-3">
        {gradeDistribution.map((item, index) => (
          <Card key={index} className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-4 h-4 rounded-full ${item.color}`} />
                <div>
                  <div className="font-medium">{getGradeBadge(item.grade)}</div>
                  <div className="text-sm text-muted-foreground">{item.count} 位成員</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-medium">{item.percentage}%</div>
                <div className="text-sm text-muted-foreground">佔比</div>
              </div>
            </div>
            <div className="mt-3">
              <div className="w-full bg-gray-200 rounded-full h-2 dark:bg-gray-700">
                <div
                  className={`h-2 rounded-full ${item.color}`}
                  style={{ width: `${item.percentage}%` }}
                />
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
