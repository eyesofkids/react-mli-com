"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Edit } from "lucide-react"

export function UpdateClaimStatusModal({ claim }) {
  const [open, setOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    status: claim.status,
    notes: "",
  })

  const statusOptions = [
    { value: "處理中", label: "處理中", color: "text-blue-600 bg-blue-50 dark:bg-blue-950 dark:text-blue-400" },
    { value: "審核中", label: "審核中", color: "text-amber-600 bg-amber-50 dark:bg-amber-950 dark:text-amber-400" },
    { value: "已完成", label: "已完成", color: "text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400" },
    { value: "已拒絕", label: "已拒絕", color: "text-red-600 bg-red-50 dark:bg-red-950 dark:text-red-400" },
  ]

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    // 模擬API調用
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("更新案件狀態:", {
      claimId: claim.id,
      ...formData,
    })

    setIsSubmitting(false)
    setOpen(false)

    alert("案件狀態更新成功！")
  }

  const getStatusBadge = (status) => {
    const statusOption = statusOptions.find(option => option.value === status)
    if (!statusOption) return status

    return (
      <Badge variant="outline" className={statusOption.color}>
        {statusOption.label}
      </Badge>
    )
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Edit className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>更新案件狀態</DialogTitle>
          <DialogDescription>
            更新案件 {claim.id} 的處理狀態
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="status">當前狀態</Label>
            <div className="p-3 border rounded-md">
              {getStatusBadge(claim.status)}
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="newStatus">新狀態</Label>
            <Select value={formData.status} onValueChange={(value) => handleInputChange("status", value)}>
              <SelectTrigger>
                <SelectValue placeholder="請選擇新狀態" />
              </SelectTrigger>
              <SelectContent>
                {statusOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="notes">更新備註</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => handleInputChange("notes", e.target.value)}
              placeholder="請輸入狀態更新原因或備註"
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              取消
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "更新中..." : "確認更新"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
