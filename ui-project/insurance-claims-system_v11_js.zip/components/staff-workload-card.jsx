"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Users, AlertTriangle } from "lucide-react"

export function StaffWorkloadCard() {
  // 模擬處理人員資料
  const staffList = [
    {
      id: "STAFF-001",
      name: "張小華",
      department: "理賠部",
      role: "資深理賠專員",
      workload: 8,
      maxWorkload: 15,
      status: "available",
    },
    {
      id: "STAFF-002",
      name: "李大明",
      department: "理賠部",
      role: "理賠專員",
      workload: 12,
      maxWorkload: 15,
      status: "available",
    },
    {
      id: "STAFF-003",
      name: "陳小芳",
      department: "理賠部",
      role: "高級理賠專員",
      workload: 5,
      maxWorkload: 12,
      status: "available",
    },
    {
      id: "STAFF-004",
      name: "王大偉",
      department: "理賠部",
      role: "理賠主管",
      workload: 15,
      maxWorkload: 15,
      status: "busy",
    },
    {
      id: "STAFF-005",
      name: "林小美",
      department: "理賠部",
      role: "理賠專員",
      workload: 3,
      maxWorkload: 15,
      status: "available",
    },
  ]

  const getWorkloadPercentage = (workload, maxWorkload) => {
    return Math.round((workload / maxWorkload) * 100)
  }

  const getStatusColor = (percentage) => {
    if (percentage >= 90) return "text-red-600"
    if (percentage >= 70) return "text-amber-600"
    return "text-green-600"
  }

  const overloadedStaff = staffList.filter((staff) => getWorkloadPercentage(staff.workload, staff.maxWorkload) >= 90)
  const availableStaff = staffList.filter((staff) => staff.status === "available")

  return (
    <Card className="col-span-3">
      <CardHeader>
        <CardTitle>處理人員工作量</CardTitle>
        <CardDescription>理賠部門人員工作量分佈</CardDescription>
      </CardHeader>
      <CardContent>
        {/* 統計概覽 */}
        <div className="flex gap-6 mb-4">
          <div className="flex flex-col items-center">
            <Users className="h-6 w-6 text-green-600" />
            <div className="text-lg font-bold">{availableStaff.length}</div>
            <div className="text-xs text-muted-foreground">可用人員</div>
          </div>
          <div className="flex flex-col items-center">
            <Users className="h-6 w-6 text-amber-600" />
            <div className="text-lg font-bold">{staffList.filter((s) => s.status === "busy").length}</div>
            <div className="text-xs text-muted-foreground">忙碌人員</div>
          </div>
          <div className="flex flex-col items-center">
            <AlertTriangle className="h-6 w-6 text-red-600" />
            <div className="text-lg font-bold">{overloadedStaff.length}</div>
            <div className="text-xs text-muted-foreground">超負荷</div>
          </div>
        </div>

        {/* 人員工作量列表 */}
        <div className="space-y-4">
          {staffList.slice(0, 5).map((staff) => {
            const percentage = getWorkloadPercentage(staff.workload, staff.maxWorkload)
            return (
              <div key={staff.id} className="flex items-center gap-4 p-2 border rounded">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{staff.name}</span>
                    {percentage >= 90 && (
                      <AlertTriangle className="h-4 w-4 text-red-600" title="超負荷" />
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground">{staff.role}</div>
                </div>
                <div className="flex flex-col items-end">
                  <span className={`text-sm font-bold ${getStatusColor(percentage)}`}>
                    {staff.workload}/{staff.maxWorkload}
                  </span>
                  <Progress value={percentage} className="w-24 h-2 mt-1" />
                </div>
              </div>
            )
          })}
        </div>

        {/* 警告提示 */}
        {overloadedStaff.length > 0 && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            <span className="font-medium text-red-700">工作量警告</span>
            <span className="text-sm text-red-600">
              {overloadedStaff.length} 位人員工作量已達上限，建議重新分配案件
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
