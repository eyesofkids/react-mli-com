"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Plus } from "lucide-react"

export function AddCustomerModal({ onCustomerAdded }) {
  const [open, setOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    idNumber: "",
    birthDate: "",
    gender: "",
    address: "",
    occupation: "",
    emergencyContact: "",
    emergencyPhone: "",
    notes: "",
  })

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    // 模擬API調用
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("新增客戶資料:", formData)

    // 創建新客戶對象
    const newCustomer = {
      id: `CUS-${Date.now()}`,
      name: formData.name,
      phone: formData.phone,
      email: formData.email,
      policies: 0,
      claims: 0,
    }

    // 調用回調函數
    if (onCustomerAdded) {
      onCustomerAdded(newCustomer)
    }

    // 重置表單
    setFormData({
      name: "",
      phone: "",
      email: "",
      idNumber: "",
      birthDate: "",
      gender: "",
      address: "",
      occupation: "",
      emergencyContact: "",
      emergencyPhone: "",
      notes: "",
    })

    setIsSubmitting(false)
    setOpen(false)

    // 這裡可以添加成功提示
    alert("客戶資料新增成功！")
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          新增客戶
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>新增客戶資料</DialogTitle>
          <DialogDescription>
            請填寫客戶的基本資訊。標有 * 的欄位為必填項目。
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 基本資訊 */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">基本資訊</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">
                  姓名 *
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="請輸入客戶姓名"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="idNumber">
                  身分證字號 *
                </Label>
                <Input
                  id="idNumber"
                  value={formData.idNumber}
                  onChange={(e) => handleInputChange("idNumber", e.target.value)}
                  placeholder="請輸入身分證字號"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="birthDate">
                  出生日期
                </Label>
                <Input
                  id="birthDate"
                  type="date"
                  value={formData.birthDate}
                  onChange={(e) => handleInputChange("birthDate", e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gender">
                  性別
                </Label>
                <Select value={formData.gender} onValueChange={(value) => handleInputChange("gender", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="請選擇性別" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">男性</SelectItem>
                    <SelectItem value="female">女性</SelectItem>
                    <SelectItem value="other">其他</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* 聯絡資訊 */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">聯絡資訊</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">
                  電話號碼 *
                </Label>
                <Input
                  id="phone"
                  value={formData.phone}
                  onChange={(e) => handleInputChange("phone", e.target.value)}
                  placeholder="請輸入電話號碼"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">
                  電子郵件
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="請輸入電子郵件"
                />
              </div>
              <div className="space-y-2 col-span-2">
                <Label htmlFor="address">
                  地址
                </Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => handleInputChange("address", e.target.value)}
                  placeholder="請輸入地址"
                />
              </div>
            </div>
          </div>

          {/* 其他資訊 */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">其他資訊</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="occupation">
                  職業
                </Label>
                <Input
                  id="occupation"
                  value={formData.occupation}
                  onChange={(e) => handleInputChange("occupation", e.target.value)}
                  placeholder="請輸入職業"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="emergencyContact">
                  緊急聯絡人
                </Label>
                <Input
                  id="emergencyContact"
                  value={formData.emergencyContact}
                  onChange={(e) => handleInputChange("emergencyContact", e.target.value)}
                  placeholder="請輸入緊急聯絡人姓名"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="emergencyPhone">
                  緊急聯絡電話
                </Label>
                <Input
                  id="emergencyPhone"
                  value={formData.emergencyPhone}
                  onChange={(e) => handleInputChange("emergencyPhone", e.target.value)}
                  placeholder="請輸入緊急聯絡電話"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">
                備註
              </Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => handleInputChange("notes", e.target.value)}
                placeholder="請輸入備註資訊"
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              取消
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "新增中..." : "新增客戶"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
