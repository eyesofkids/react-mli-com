"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, TrendingUp, TrendingDown } from "lucide-react"

export function StaffPerformanceComparison() {
  const performanceData = [
    {
      name: "張小華",
      role: "資深理賠專員",
      avgProcessingTime: 2.8,
      completionRate: 96.5,
      satisfaction: 4.9,
      workload: 8,
      grade: "A",
    },
    {
      name: "李大明",
      role: "理賠專員",
      avgProcessingTime: 3.5,
      completionRate: 92.0,
      satisfaction: 4.7,
      workload: 12,
      grade: "B",
    },
    {
      name: "陳小芳",
      role: "高級理賠專員",
      avgProcessingTime: 3.2,
      completionRate: 94.2,
      satisfaction: 4.8,
      workload: 10,
      grade: "A",
    },
    {
      name: "王大偉",
      role: "理賠主管",
      avgProcessingTime: 4.1,
      completionRate: 89.5,
      satisfaction: 4.6,
      workload: 15,
      grade: "B",
    },
    {
      name: "林小美",
      role: "理賠專員",
      avgProcessingTime: 3.8,
      completionRate: 91.3,
      satisfaction: 4.5,
      workload: 9,
      grade: "C",
    },
  ]

  const getGradeBadge = (grade) => {
    switch (grade) {
      case "A":
        return (
          <Badge variant="outline" className="text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400">
            A 級
          </Badge>
        )
      case "B":
        return (
          <Badge variant="outline" className="text-blue-600 bg-blue-50 dark:bg-blue-950 dark:text-blue-400">
            B 級
          </Badge>
        )
      case "C":
        return (
          <Badge variant="outline" className="text-amber-600 bg-amber-50 dark:bg-amber-950 dark:text-amber-400">
            C 級
          </Badge>
        )
      default:
        return grade
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">團隊績效比較</h3>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Users className="h-4 w-4" />
          {performanceData.length} 位成員
        </div>
      </div>
      <div className="space-y-3">
        {performanceData.map((staff, index) => (
          <Card key={index} className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Users className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="font-medium">{staff.name}</div>
                  <div className="text-sm text-muted-foreground">{staff.role}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getGradeBadge(staff.grade)}
              </div>
            </div>
            <div className="mt-4 grid grid-cols-4 gap-4 text-sm">
              <div>
                <div className="text-muted-foreground">平均處理時間</div>
                <div className="font-medium">{staff.avgProcessingTime} 天</div>
              </div>
              <div>
                <div className="text-muted-foreground">案件完成率</div>
                <div className="font-medium">{staff.completionRate}%</div>
              </div>
              <div>
                <div className="text-muted-foreground">客戶滿意度</div>
                <div className="font-medium">{staff.satisfaction}/5</div>
              </div>
              <div>
                <div className="text-muted-foreground">工作量</div>
                <div className="font-medium">{staff.workload} 件</div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
