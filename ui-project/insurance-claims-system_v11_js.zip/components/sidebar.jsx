"use client"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { BarChart3, FileText, Users, Settings, HelpCircle, Home, Award } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { ThemeToggle } from "@/components/theme-toggle"

export function Sidebar({ className }) {
  const pathname = usePathname()

  const routes = [
    {
      label: "首頁",
      icon: Home,
      href: "/",
      color: "text-sky-500",
    },
    {
      label: "理賠案件管理",
      icon: FileText,
      href: "/claims",
      color: "text-violet-500",
    },
    {
      label: "客戶資料",
      icon: Users,
      href: "/customers",
      color: "text-pink-700",
    },
    {
      label: "人員績效",
      icon: Award,
      href: "/performance",
      color: "text-green-600",
    },
    {
      label: "統計報表",
      icon: BarChart3,
      href: "/reports",
      color: "text-orange-500",
    },
    {
      label: "系統設定",
      icon: Settings,
      href: "/settings",
      color: "text-gray-500",
    },
    {
      label: "幫助中心",
      icon: HelpCircle,
      href: "/help",
      color: "text-green-500",
    },
  ]

  return (
    <div className={cn("pb-12 border-r bg-background h-full w-64", className)}>
      <div className="space-y-4 py-4">
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold tracking-tight">保險理賠系統</h2>
          <div className="space-y-1">
            {routes.map((route) => (
              <Button
                key={route.href}
                variant={pathname === route.href ? "secondary" : "ghost"}
                className={cn("w-full justify-start", pathname === route.href && "bg-accent")}
                asChild
              >
                <Link href={route.href}>
                  <route.icon className={cn("mr-2 h-4 w-4", route.color)} />
                  {route.label}
                </Link>
              </Button>
            ))}
          </div>
        </div>
      </div>
      <div className="px-3 py-2 border-t">
        <div className="flex items-center justify-between px-4 py-2">
          <div className="flex items-center">
            <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center mr-2">
              <Users className="h-4 w-4" />
            </div>
            <div>
              <p className="text-sm font-medium">管理員</p>
              <p className="text-xs text-muted-foreground">admin@example.com</p>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </div>
    </div>
  )
} 