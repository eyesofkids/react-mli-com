"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowUpDown, TrendingUp, TrendingDown, Minus } from "lucide-react"

export function StaffPerformanceTable() {
  const [sortColumn, setSortColumn] = useState("score")
  const [sortDirection, setSortDirection] = useState("desc")

  const performanceData = [
    {
      id: 1,
      name: "張小華",
      role: "資深理賠專員",
      avgProcessingTime: 2.8,
      completionRate: 96.5,
      satisfaction: 4.9,
      workload: 8,
      score: 95,
      grade: "A",
      trend: "up",
    },
    {
      id: 2,
      name: "陳小芳",
      role: "高級理賠專員",
      avgProcessingTime: 3.2,
      completionRate: 94.2,
      satisfaction: 4.8,
      workload: 10,
      score: 92,
      grade: "A",
      trend: "up",
    },
    {
      id: 3,
      name: "李大明",
      role: "理賠專員",
      avgProcessingTime: 3.5,
      completionRate: 92.0,
      satisfaction: 4.7,
      workload: 12,
      score: 88,
      grade: "B",
      trend: "stable",
    },
    {
      id: 4,
      name: "王大偉",
      role: "理賠主管",
      avgProcessingTime: 4.1,
      completionRate: 89.5,
      satisfaction: 4.6,
      workload: 15,
      score: 85,
      grade: "B",
      trend: "down",
    },
    {
      id: 5,
      name: "林小美",
      role: "理賠專員",
      avgProcessingTime: 3.8,
      completionRate: 91.3,
      satisfaction: 4.5,
      workload: 9,
      score: 82,
      grade: "C",
      trend: "up",
    },
  ]

  const getGradeBadge = (grade) => {
    switch (grade) {
      case "A":
        return (
          <Badge variant="outline" className="text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400">
            A 級
          </Badge>
        )
      case "B":
        return (
          <Badge variant="outline" className="text-blue-600 bg-blue-50 dark:bg-blue-950 dark:text-blue-400">
            B 級
          </Badge>
        )
      case "C":
        return (
          <Badge variant="outline" className="text-amber-600 bg-amber-50 dark:bg-amber-950 dark:text-amber-400">
            C 級
          </Badge>
        )
      default:
        return grade
    }
  }

  const getTrendIcon = (trend) => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-green-500" />
      case "down":
        return <TrendingDown className="h-4 w-4 text-red-500" />
      case "stable":
        return <Minus className="h-4 w-4 text-gray-500" />
      default:
        return null
    }
  }

  const handleSort = (column) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortColumn(column)
      setSortDirection("desc")
    }
  }

  const sortedData = [...performanceData].sort((a, b) => {
    const aValue = a[sortColumn]
    const bValue = b[sortColumn]
    
    if (sortDirection === "asc") {
      return aValue > bValue ? 1 : -1
    } else {
      return aValue < bValue ? 1 : -1
    }
  })

  return (
    <div className="space-y-4">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>排名</TableHead>
            <TableHead>姓名</TableHead>
            <TableHead>職位</TableHead>
            <TableHead>
              <Button
                variant="ghost"
                onClick={() => handleSort("avgProcessingTime")}
                className="h-auto p-0 font-normal"
              >
                平均處理時間
                <ArrowUpDown className="ml-2 h-4 w-4" />
              </Button>
            </TableHead>
            <TableHead>
              <Button
                variant="ghost"
                onClick={() => handleSort("completionRate")}
                className="h-auto p-0 font-normal"
              >
                完成率
                <ArrowUpDown className="ml-2 h-4 w-4" />
              </Button>
            </TableHead>
            <TableHead>
              <Button
                variant="ghost"
                onClick={() => handleSort("satisfaction")}
                className="h-auto p-0 font-normal"
              >
                滿意度
                <ArrowUpDown className="ml-2 h-4 w-4" />
              </Button>
            </TableHead>
            <TableHead>
              <Button
                variant="ghost"
                onClick={() => handleSort("workload")}
                className="h-auto p-0 font-normal"
              >
                工作量
                <ArrowUpDown className="ml-2 h-4 w-4" />
              </Button>
            </TableHead>
            <TableHead>
              <Button
                variant="ghost"
                onClick={() => handleSort("score")}
                className="h-auto p-0 font-normal"
              >
                綜合評分
                <ArrowUpDown className="ml-2 h-4 w-4" />
              </Button>
            </TableHead>
            <TableHead>等級</TableHead>
            <TableHead>趨勢</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedData.map((staff, index) => (
            <TableRow key={staff.id}>
              <TableCell className="font-medium">{index + 1}</TableCell>
              <TableCell className="font-medium">{staff.name}</TableCell>
              <TableCell>{staff.role}</TableCell>
              <TableCell>{staff.avgProcessingTime} 天</TableCell>
              <TableCell>{staff.completionRate}%</TableCell>
              <TableCell>{staff.satisfaction}/5</TableCell>
              <TableCell>{staff.workload} 件</TableCell>
              <TableCell className="font-medium">{staff.score} 分</TableCell>
              <TableCell>{getGradeBadge(staff.grade)}</TableCell>
              <TableCell>{getTrendIcon(staff.trend)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
