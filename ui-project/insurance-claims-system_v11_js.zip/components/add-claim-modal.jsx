"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Plus } from "lucide-react"

export function AddClaimModal() {
  const [open, setOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    customerName: "",
    claimType: "",
    incidentDate: "",
    description: "",
    estimatedAmount: "",
    policeReport: "",
    reportNumber: "",
  })

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    // 模擬API調用
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("新增理賠案件:", formData)

    // 重置表單
    setFormData({
      customerName: "",
      claimType: "",
      incidentDate: "",
      description: "",
      estimatedAmount: "",
      policeReport: "",
      reportNumber: "",
    })

    setIsSubmitting(false)
    setOpen(false)

    alert("理賠案件新增成功！")
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          新增理賠案件
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>新增理賠案件</DialogTitle>
          <DialogDescription>
            請填寫理賠案件的基本資訊。標有 * 的欄位為必填項目。
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 基本資訊 */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">基本資訊</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="customerName">
                  客戶姓名 *
                </Label>
                <Input
                  id="customerName"
                  value={formData.customerName}
                  onChange={(e) => handleInputChange("customerName", e.target.value)}
                  placeholder="請輸入客戶姓名"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="claimType">
                  理賠類型 *
                </Label>
                <Select value={formData.claimType} onValueChange={(value) => handleInputChange("claimType", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="請選擇理賠類型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="car">車禍理賠</SelectItem>
                    <SelectItem value="medical">醫療理賠</SelectItem>
                    <SelectItem value="property">財產損失</SelectItem>
                    <SelectItem value="life">人壽理賠</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="incidentDate">
                  事故日期 *
                </Label>
                <Input
                  id="incidentDate"
                  type="date"
                  value={formData.incidentDate}
                  onChange={(e) => handleInputChange("incidentDate", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="estimatedAmount">
                  預估理賠金額 *
                </Label>
                <Input
                  id="estimatedAmount"
                  type="number"
                  value={formData.estimatedAmount}
                  onChange={(e) => handleInputChange("estimatedAmount", e.target.value)}
                  placeholder="請輸入預估金額"
                  required
                />
              </div>
            </div>
          </div>

          {/* 詳細資訊 */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">詳細資訊</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="description">
                  事故描述 *
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => handleInputChange("description", e.target.value)}
                  placeholder="請詳細描述事故經過"
                  rows={4}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="policeReport">
                    警方報告
                  </Label>
                  <Input
                    id="policeReport"
                    value={formData.policeReport}
                    onChange={(e) => handleInputChange("policeReport", e.target.value)}
                    placeholder="請輸入警方報告編號"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reportNumber">
                    報案編號
                  </Label>
                  <Input
                    id="reportNumber"
                    value={formData.reportNumber}
                    onChange={(e) => handleInputChange("reportNumber", e.target.value)}
                    placeholder="請輸入報案編號"
                  />
                </div>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              取消
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "新增中..." : "新增案件"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
