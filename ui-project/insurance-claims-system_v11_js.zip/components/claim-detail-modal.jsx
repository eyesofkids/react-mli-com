"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Eye, Calendar, DollarSign, User, FileText, Clock, CheckCircle2, AlertCircle } from "lucide-react"
import { AssignClaimModal } from "@/components/assign-claim-modal"
import { AssignmentHistoryModal } from "@/components/assignment-history-modal"

export function ClaimDetailModal({ claim }) {
  const [open, setOpen] = useState(false)

  const getStatusBadge = (status) => {
    switch (status) {
      case "處理中":
        return (
          <Badge
            variant="outline"
            className="text-blue-600 bg-blue-50 dark:bg-blue-950 dark:text-blue-400"
          >
            處理中
          </Badge>
        )
      case "已完成":
        return (
          <Badge
            variant="outline"
            className="text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400"
          >
            已完成
          </Badge>
        )
      case "審核中":
        return (
          <Badge
            variant="outline"
            className="text-amber-600 bg-amber-50 dark:bg-amber-950 dark:text-amber-400"
          >
            審核中
          </Badge>
        )
      default:
        return status
    }
  }

  // 模擬案件詳細資料
  const claimDetail = {
    ...claim,
    customerId: "CUS-001",
    customerName: claim.customer,
    customerPhone: "0912-345-678",
    customerEmail: "wang@example.com",
    incidentDate: "2023-05-10",
    reportDate: claim.date,
    estimatedAmount: claim.amount,
    actualAmount: claim.status === "已完成" ? claim.amount * 0.9 : null,
    description: "客戶在高速公路上發生追撞事故，車輛前保險桿受損，需要更換。",
    documents: [
      { id: "doc-1", name: "事故現場照片", type: "image", uploadedAt: "2023-05-15" },
      { id: "doc-2", name: "警方事故報告", type: "pdf", uploadedAt: "2023-05-16" },
      { id: "doc-3", name: "維修估價單", type: "pdf", uploadedAt: "2023-05-17" },
    ],
    timeline: [
      { date: "2023-05-15", action: "案件建立", description: "客戶提交理賠申請" },
      { date: "2023-05-16", action: "資料審核", description: "審核提交的文件資料" },
      { date: "2023-05-17", action: "現場勘查", description: "安排理賠專員現場勘查" },
      { date: "2023-05-18", action: "理賠評估", description: "評估理賠金額" },
    ],
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Eye className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>案件詳細資料</DialogTitle>
          <DialogDescription>
            查看案件 {claim.id} 的完整資訊和處理進度
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-6">
          {/* 案件基本資訊 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                基本資訊
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <FileText className="h-4 w-4" />
                    案件編號
                  </div>
                  <div className="font-medium">{claim.id}</div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <User className="h-4 w-4" />
                    客戶姓名
                  </div>
                  <div className="font-medium">{claimDetail.customerName}</div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    申請日期
                  </div>
                  <div className="font-medium">{claim.date}</div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <DollarSign className="h-4 w-4" />
                    理賠金額
                  </div>
                  <div className="font-medium">{claim.amount.toLocaleString()} 元</div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    案件狀態
                  </div>
                  <div>{getStatusBadge(claim.status)}</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 詳細資訊標籤頁 */}
          <Tabs defaultValue="details" className="space-y-4">
            <TabsList>
              <TabsTrigger value="details">案件詳情</TabsTrigger>
              <TabsTrigger value="documents">文件資料</TabsTrigger>
              <TabsTrigger value="timeline">處理進度</TabsTrigger>
            </TabsList>
            <TabsContent value="details" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>案件描述</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{claimDetail.description}</p>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="documents" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>相關文件</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>文件名稱</TableHead>
                        <TableHead>類型</TableHead>
                        <TableHead>上傳日期</TableHead>
                        <TableHead>操作</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {claimDetail.documents.map((doc) => (
                        <TableRow key={doc.id}>
                          <TableCell>{doc.name}</TableCell>
                          <TableCell>{doc.type.toUpperCase()}</TableCell>
                          <TableCell>{doc.uploadedAt}</TableCell>
                          <TableCell>
                            <Button variant="outline" size="sm">
                              查看
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="timeline" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>處理進度</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {claimDetail.timeline.map((event, index) => (
                      <div key={index} className="flex items-start gap-4">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                          <CheckCircle2 className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1">
                          <div className="font-medium">{event.action}</div>
                          <div className="text-sm text-muted-foreground">{event.description}</div>
                          <div className="text-xs text-muted-foreground">{event.date}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  )
}
