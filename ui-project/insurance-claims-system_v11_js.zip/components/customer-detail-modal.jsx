"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Eye, Phone, Mail, MapPin, Calendar, User, FileText, Award } from "lucide-react"

export function CustomerDetailModal({ customer }) {
  const [open, setOpen] = useState(false)

  // 模擬保單數據
  const policies = [
    {
      id: "POL-001",
      type: "汽車保險",
      startDate: "2023-01-15",
      endDate: "2024-01-15",
      premium: 15000,
      status: "有效",
    },
    {
      id: "POL-002",
      type: "醫療保險",
      startDate: "2023-03-20",
      endDate: "2024-03-20",
      premium: 8000,
      status: "有效",
    },
  ]

  // 模擬理賠記錄
  const claims = [
    {
      id: "CL-2023-001",
      type: "車禍理賠",
      date: "2023-05-15",
      amount: 45000,
      status: "已完成",
    },
  ]

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Eye className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>客戶詳細資料</DialogTitle>
          <DialogDescription>
            查看客戶的完整資訊、保單記錄和理賠歷史
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-6">
          {/* 客戶基本資訊 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                基本資訊
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <User className="h-4 w-4" />
                    姓名
                  </div>
                  <div className="font-medium">{customer.name}</div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone className="h-4 w-4" />
                    電話
                  </div>
                  <div className="font-medium">{customer.phone}</div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Mail className="h-4 w-4" />
                    電子郵件
                  </div>
                  <div className="font-medium">{customer.email}</div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <FileText className="h-4 w-4" />
                    保單數量
                  </div>
                  <div className="font-medium">{customer.policies} 張</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 詳細資訊標籤頁 */}
          <Tabs defaultValue="policies" className="space-y-4">
            <TabsList>
              <TabsTrigger value="policies">保單記錄</TabsTrigger>
              <TabsTrigger value="claims">理賠記錄</TabsTrigger>
              <TabsTrigger value="analytics">分析統計</TabsTrigger>
            </TabsList>
            <TabsContent value="policies" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>保單記錄</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>保單編號</TableHead>
                        <TableHead>保險類型</TableHead>
                        <TableHead>生效日期</TableHead>
                        <TableHead>到期日期</TableHead>
                        <TableHead>保費</TableHead>
                        <TableHead>狀態</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {policies.map((policy) => (
                        <TableRow key={policy.id}>
                          <TableCell>{policy.id}</TableCell>
                          <TableCell>{policy.type}</TableCell>
                          <TableCell>{policy.startDate}</TableCell>
                          <TableCell>{policy.endDate}</TableCell>
                          <TableCell>{policy.premium.toLocaleString()} 元</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400">
                              {policy.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="claims" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>理賠記錄</CardTitle>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>案件編號</TableHead>
                        <TableHead>理賠類型</TableHead>
                        <TableHead>申請日期</TableHead>
                        <TableHead>理賠金額</TableHead>
                        <TableHead>狀態</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {claims.map((claim) => (
                        <TableRow key={claim.id}>
                          <TableCell>{claim.id}</TableCell>
                          <TableCell>{claim.type}</TableCell>
                          <TableCell>{claim.date}</TableCell>
                          <TableCell>{claim.amount.toLocaleString()} 元</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400">
                              {claim.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="analytics" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">總保費</CardTitle>
                    <Award className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">23,000 元</div>
                    <p className="text-xs text-muted-foreground">年度總保費</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">理賠次數</CardTitle>
                    <FileText className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{customer.claims}</div>
                    <p className="text-xs text-muted-foreground">歷史理賠次數</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">客戶等級</CardTitle>
                    <User className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">A 級</div>
                    <p className="text-xs text-muted-foreground">優質客戶</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">投保年資</CardTitle>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">2 年</div>
                    <p className="text-xs text-muted-foreground">累計投保時間</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  )
}
