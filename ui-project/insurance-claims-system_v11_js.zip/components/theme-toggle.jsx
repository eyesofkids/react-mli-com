"use client"

import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Sun, Moon, Laptop } from "lucide-react"

export function ThemeToggle() {
  const { setTheme } = useTheme()

  return (
    <div className="flex gap-2">
      <Button variant="outline" size="icon" onClick={() => setTheme("light")}>
        <Sun className="h-4 w-4" />
        <span className="sr-only">淺色模式</span>
      </Button>
      <Button variant="outline" size="icon" onClick={() => setTheme("dark")}>
        <Moon className="h-4 w-4" />
        <span className="sr-only">深色模式</span>
      </Button>
      <Button variant="outline" size="icon" onClick={() => setTheme("system")}>
        <Laptop className="h-4 w-4" />
        <span className="sr-only">系統預設</span>
      </Button>
    </div>
  )
}