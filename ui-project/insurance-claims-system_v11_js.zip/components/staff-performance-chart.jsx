"use client"

import { LineChart } from "lucide-react"

export function StaffPerformanceChart() {
  return (
    <div className="p-6 bg-white rounded-lg border shadow-sm">
      <div className="flex gap-2 items-center mb-4">
        <LineChart className="w-5 h-5 text-blue-600" />
        <h3 className="text-lg font-semibold">绩效趋势图表</h3>
      </div>
      <div className="flex justify-center items-center h-64 text-gray-500">
        绩效趋势图表区域
      </div>
    </div>
  )
}
