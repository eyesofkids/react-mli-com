"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Trash2 } from "lucide-react"

export function DeleteCustomerModal({ customer, onCustomerDeleted }) {
  const [open, setOpen] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)

  const handleDelete = async () => {
    setIsDeleting(true)
    
    // 模擬API調用
    await new Promise((resolve) => setTimeout(resolve, 1000))
    
    console.log("刪除客戶:", customer.id)
    
    // 調用回調函數
    if (onCustomerDeleted) {
      onCustomerDeleted(customer.id)
    }
    
    setIsDeleting(false)
    setOpen(false)
    
    alert("客戶資料已刪除！")
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Trash2 className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>確認刪除客戶</DialogTitle>
          <DialogDescription>
            您確定要刪除客戶 "{customer.name}" 嗎？此操作無法撤銷。
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            取消
          </Button>
          <Button variant="destructive" onClick={handleDelete} disabled={isDeleting}>
            {isDeleting ? "刪除中..." : "確認刪除"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
