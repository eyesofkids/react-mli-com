"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { History } from "lucide-react"

export function AssignmentHistoryModal({ claim }) {
  const [open, setOpen] = useState(false)

  // 模擬分配歷史記錄
  const assignmentHistory = [
    {
      id: 1,
      date: "2023-05-16 09:15",
      assignedTo: "張小華",
      role: "資深理賠專員",
      reason: "專業對口，工作量適中",
      assignedBy: "系統管理員",
      status: "active",
    },
    {
      id: 2,
      date: "2023-05-15 14:30",
      assignedTo: "李大明",
      role: "理賠專員",
      reason: "初始分配",
      assignedBy: "系統自動",
      status: "transferred",
    },
  ]

  const getStatusBadge = (status) => {
    switch (status) {
      case "active":
        return (
          <Badge variant="outline" className="text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400">
            當前處理人
          </Badge>
        )
      case "transferred":
        return (
          <Badge variant="outline" className="text-gray-600 bg-gray-50 dark:bg-gray-950 dark:text-gray-400">
            已轉移
          </Badge>
        )
      default:
        return status
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <History className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>分配歷史記錄</DialogTitle>
          <DialogDescription>
            查看案件 {claim.id} 的分配歷史
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>分配時間</TableHead>
                <TableHead>處理人員</TableHead>
                <TableHead>分配原因</TableHead>
                <TableHead>分配人</TableHead>
                <TableHead>狀態</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assignmentHistory.map((record) => (
                <TableRow key={record.id}>
                  <TableCell>{record.date}</TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{record.assignedTo}</div>
                      <div className="text-sm text-muted-foreground">{record.role}</div>
                    </div>
                  </TableCell>
                  <TableCell>{record.reason}</TableCell>
                  <TableCell>{record.assignedBy}</TableCell>
                  <TableCell>{getStatusBadge(record.status)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </DialogContent>
    </Dialog>
  )
}
