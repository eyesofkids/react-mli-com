import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Search, Filter, Plus, Eye, Edit } from "lucide-react"
import { Input } from "@/components/ui/input"
import { ClaimDetailModal } from "@/components/claim-detail-modal"
import { UpdateClaimStatusModal } from "@/components/update-claim-status-modal"
import { AddClaimModal } from "@/components/add-claim-modal"
import { AssignClaimModal } from "@/components/assign-claim-modal"

export default function ClaimsPage() {
  const claims = [
    {
      id: "CL-2023-001",
      customer: "王小明",
      type: "車禍理賠",
      date: "2023-05-15",
      amount: 45000,
      status: "處理中",
    },
    {
      id: "CL-2023-002",
      customer: "李小華",
      type: "醫療理賠",
      date: "2023-05-18",
      amount: 12500,
      status: "已完成",
    },
    {
      id: "CL-2023-003",
      customer: "張大山",
      type: "財產損失",
      date: "2023-05-20",
      amount: 78000,
      status: "審核中",
    },
    {
      id: "CL-2023-004",
      customer: "陳小芳",
      type: "醫療理賠",
      date: "2023-05-22",
      amount: 9800,
      status: "已完成",
    },
    {
      id: "CL-2023-005",
      customer: "林大為",
      type: "車禍理賠",
      date: "2023-05-25",
      amount: 35000,
      status: "處理中",
    },
  ]

  const getStatusBadge = (status) => {
    switch (status) {
      case "處理中":
        return (
          <Badge
            variant="outline"
            className="text-blue-600 bg-blue-50 dark:bg-blue-950 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950"
          >
            處理中
          </Badge>
        )
      case "已完成":
        return (
          <Badge
            variant="outline"
            className="text-green-600 bg-green-50 dark:bg-green-950 dark:text-green-400 hover:bg-green-50 dark:hover:bg-green-950"
          >
            已完成
          </Badge>
        )
      case "審核中":
        return (
          <Badge
            variant="outline"
            className="text-amber-600 bg-amber-50 dark:bg-amber-950 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950"
          >
            審核中
          </Badge>
        )
      default:
        return status
    }
  }

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">理賠案件管理</h2>
        <div className="flex items-center space-x-2">
          <AddClaimModal />
        </div>
      </div>
      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">全部案件</TabsTrigger>
          <TabsTrigger value="processing">處理中</TabsTrigger>
          <TabsTrigger value="reviewing">審核中</TabsTrigger>
          <TabsTrigger value="completed">已完成</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>全部理賠案件</CardTitle>
              <CardDescription>管理所有的理賠案件記錄</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>案件編號</TableHead>
                    <TableHead>客戶姓名</TableHead>
                    <TableHead>理賠類型</TableHead>
                    <TableHead>申請日期</TableHead>
                    <TableHead>理賠金額</TableHead>
                    <TableHead>狀態</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {claims.map((claim) => (
                    <TableRow key={claim.id}>
                      <TableCell>{claim.id}</TableCell>
                      <TableCell>{claim.customer}</TableCell>
                      <TableCell>{claim.type}</TableCell>
                      <TableCell>{claim.date}</TableCell>
                      <TableCell>{claim.amount.toLocaleString()} 元</TableCell>
                      <TableCell>{getStatusBadge(claim.status)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <ClaimDetailModal claim={claim} />
                          <UpdateClaimStatusModal claim={claim} />
                          <AssignClaimModal claim={claim} />
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="processing" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>處理中案件</CardTitle>
              <CardDescription>正在處理中的理賠案件</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>案件編號</TableHead>
                    <TableHead>客戶姓名</TableHead>
                    <TableHead>理賠類型</TableHead>
                    <TableHead>申請日期</TableHead>
                    <TableHead>理賠金額</TableHead>
                    <TableHead>狀態</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {claims
                    .filter((claim) => claim.status === "處理中")
                    .map((claim) => (
                      <TableRow key={claim.id}>
                        <TableCell>{claim.id}</TableCell>
                        <TableCell>{claim.customer}</TableCell>
                        <TableCell>{claim.type}</TableCell>
                        <TableCell>{claim.date}</TableCell>
                        <TableCell>{claim.amount.toLocaleString()} 元</TableCell>
                        <TableCell>{getStatusBadge(claim.status)}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <ClaimDetailModal claim={claim} />
                            <UpdateClaimStatusModal claim={claim} />
                            <AssignClaimModal claim={claim} />
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="reviewing" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>審核中案件</CardTitle>
              <CardDescription>正在審核中的理賠案件</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>案件編號</TableHead>
                    <TableHead>客戶姓名</TableHead>
                    <TableHead>理賠類型</TableHead>
                    <TableHead>申請日期</TableHead>
                    <TableHead>理賠金額</TableHead>
                    <TableHead>狀態</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {claims
                    .filter((claim) => claim.status === "審核中")
                    .map((claim) => (
                      <TableRow key={claim.id}>
                        <TableCell>{claim.id}</TableCell>
                        <TableCell>{claim.customer}</TableCell>
                        <TableCell>{claim.type}</TableCell>
                        <TableCell>{claim.date}</TableCell>
                        <TableCell>{claim.amount.toLocaleString()} 元</TableCell>
                        <TableCell>{getStatusBadge(claim.status)}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <ClaimDetailModal claim={claim} />
                            <UpdateClaimStatusModal claim={claim} />
                            <AssignClaimModal claim={claim} />
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="completed" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>已完成案件</CardTitle>
              <CardDescription>已完成處理的理賠案件</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>案件編號</TableHead>
                    <TableHead>客戶姓名</TableHead>
                    <TableHead>理賠類型</TableHead>
                    <TableHead>申請日期</TableHead>
                    <TableHead>理賠金額</TableHead>
                    <TableHead>狀態</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {claims
                    .filter((claim) => claim.status === "已完成")
                    .map((claim) => (
                      <TableRow key={claim.id}>
                        <TableCell>{claim.id}</TableCell>
                        <TableCell>{claim.customer}</TableCell>
                        <TableCell>{claim.type}</TableCell>
                        <TableCell>{claim.date}</TableCell>
                        <TableCell>{claim.amount.toLocaleString()} 元</TableCell>
                        <TableCell>{getStatusBadge(claim.status)}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <ClaimDetailModal claim={claim} />
                            <UpdateClaimStatusModal claim={claim} />
                            <AssignClaimModal claim={claim} />
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
