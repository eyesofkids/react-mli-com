"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Search, Filter, Plus } from "lucide-react"
import { AddCustomerModal } from "@/components/add-customer-modal"
import { CustomerDetailModal } from "@/components/customer-detail-modal"
import { EditCustomerModal } from "@/components/edit-customer-modal"
import { DeleteCustomerModal } from "@/components/delete-customer-modal"
import { Toaster } from "@/components/ui/toaster"

export default function CustomersPage() {
  const [customers, setCustomers] = useState([
    {
      id: "CUS-001",
      name: "王小明",
      phone: "0912-345-678",
      email: "wang@example.com",
      policies: 2,
      claims: 1,
    },
    {
      id: "CUS-002",
      name: "李小華",
      phone: "0923-456-789",
      email: "lee@example.com",
      policies: 1,
      claims: 1,
    },
    {
      id: "CUS-003",
      name: "張大山",
      phone: "0934-567-890",
      email: "chang@example.com",
      policies: 3,
      claims: 1,
    },
    {
      id: "CUS-004",
      name: "陳小芳",
      phone: "0945-678-901",
      email: "chen@example.com",
      policies: 1,
      claims: 1,
    },
    {
      id: "CUS-005",
      name: "林大為",
      phone: "0956-789-012",
      email: "lin@example.com",
      policies: 2,
      claims: 1,
    },
  ])

  const handleDeleteCustomer = (customerId) => {
    setCustomers((prevCustomers) => prevCustomers.filter((customer) => customer.id !== customerId))
  }

  const handleUpdateCustomer = (updatedCustomer) => {
    setCustomers((prevCustomers) =>
      prevCustomers.map((customer) => (customer.id === updatedCustomer.id ? updatedCustomer : customer)),
    )
  }

  return (
    <div className="flex-1 space-y-4 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">客戶資料管理</h2>
        <div className="flex items-center space-x-2">
          <AddCustomerModal onCustomerAdded={(newCustomer) => setCustomers([...customers, newCustomer])} />
        </div>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>客戶列表</CardTitle>
          <CardDescription>管理所有客戶資料</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center py-4">
            <div className="relative">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="搜尋客戶..." className="pl-8" />
            </div>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>客戶編號</TableHead>
                <TableHead>姓名</TableHead>
                <TableHead>電話</TableHead>
                <TableHead>電子郵件</TableHead>
                <TableHead>保單數量</TableHead>
                <TableHead>理賠案件</TableHead>
                <TableHead>操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {customers.map((customer) => (
                <TableRow key={customer.id}>
                  <TableCell>{customer.id}</TableCell>
                  <TableCell>{customer.name}</TableCell>
                  <TableCell>{customer.phone}</TableCell>
                  <TableCell>{customer.email}</TableCell>
                  <TableCell>{customer.policies}</TableCell>
                  <TableCell>{customer.claims}</TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <CustomerDetailModal customer={customer} />
                      <EditCustomerModal 
                        customer={customer} 
                        onCustomerUpdated={handleUpdateCustomer}
                      />
                      <DeleteCustomerModal 
                        customer={customer} 
                        onCustomerDeleted={handleDeleteCustomer}
                      />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
