import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { LineChart, PieChart, Download, Calendar, TrendingUp, Users, Award, Clock } from "lucide-react"
import { StaffPerformanceTable } from "@/components/staff-performance-table"
import { StaffPerformanceChart } from "@/components/staff-performance-chart"
import { StaffPerformanceMetrics } from "@/components/staff-performance-metrics"
import { StaffPerformanceComparison } from "@/components/staff-performance-comparison"

export default function PerformancePage() {
  return (
    <div className="flex-1 p-8 pt-6 space-y-4">
      <div className="flex justify-between items-center space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">績效統計與分析</h2>
        <div className="flex items-center space-x-2">
          <Select defaultValue="week">
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">本週</SelectItem>
              <SelectItem value="month">本月</SelectItem>
              <SelectItem value="quarter">本季度</SelectItem>
              <SelectItem value="year">本年度</SelectItem>
              <SelectItem value="custom">自訂範圍</SelectItem>
            </SelectContent>
          </Select>
          <Button>
            <Download className="mr-2 w-4 h-4" />
            匯出報告
          </Button>
        </div>
      </div>
      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">績效總覽</TabsTrigger>
          <TabsTrigger value="individual">個人績效</TabsTrigger>
          <TabsTrigger value="team">團隊比較</TabsTrigger>
          <TabsTrigger value="trends">績效趨勢</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row justify-between items-center pb-2 space-y-0">
                <CardTitle className="text-sm font-medium">平均處理時間</CardTitle>
                <Clock className="w-4 h-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3.2 天</div>
                <p className="text-xs text-muted-foreground">較上月 -0.5 天</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row justify-between items-center pb-2 space-y-0">
                <CardTitle className="text-sm font-medium">案件完成率</CardTitle>
                <TrendingUp className="w-4 h-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">92.5%</div>
                <p className="text-xs text-muted-foreground">較上月 +2.3%</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row justify-between items-center pb-2 space-y-0">
                <CardTitle className="text-sm font-medium">客戶滿意度</CardTitle>
                <Award className="w-4 h-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4.7/5</div>
                <p className="text-xs text-muted-foreground">較上月 +0.2</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row justify-between items-center pb-2 space-y-0">
                <CardTitle className="text-sm font-medium">平均工作量</CardTitle>
                <Users className="w-4 h-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8.6 件</div>
                <p className="text-xs text-muted-foreground">較上月 +0.8 件</p>
              </CardContent>
            </Card>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-4">
              <CardHeader>
                <CardTitle>績效趨勢</CardTitle>
                <CardDescription>過去30天的關鍵績效指標趨勢</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <StaffPerformanceChart />
              </CardContent>
            </Card>
            <Card className="col-span-3">
              <CardHeader>
                <CardTitle>績效分佈</CardTitle>
                <CardDescription>各績效等級人員分佈</CardDescription>
              </CardHeader>
              <CardContent className="pl-2">
                <StaffPerformanceComparison />
              </CardContent>
            </Card>
          </div>
          <Card>
            <CardHeader>
              <CardTitle>處理人員績效排名</CardTitle>
              <CardDescription>按綜合績效評分排序</CardDescription>
            </CardHeader>
            <CardContent>
              <StaffPerformanceTable />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="individual" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle>個人績效詳情</CardTitle>
                <CardDescription>選擇處理人員查看詳細績效數據</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="p-2 rounded-lg cursor-pointer bg-primary/10">
                    張小華 (資深理賠專員)
                  </div>
                  <div className="p-2 rounded-lg cursor-pointer hover:bg-muted">
                    李大明 (理賠專員)
                  </div>
                  <div className="p-2 rounded-lg cursor-pointer hover:bg-muted">
                    陳小芳 (高級理賠專員)
                  </div>
                  <div className="p-2 rounded-lg cursor-pointer hover:bg-muted">
                    王大偉 (理賠主管)
                  </div>
                  <div className="p-2 rounded-lg cursor-pointer hover:bg-muted">
                    林小美 (理賠專員)
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="col-span-5">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <div className="flex justify-center items-center w-12 h-12 rounded-full bg-primary/10">
                    <Users className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold">張小華</h3>
                    <p className="text-sm text-muted-foreground">資深理賠專員</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  加入時間：2020-03-15 | 專長：車禍理賠、財產損失
                </p>
                <div className="flex space-x-2">
                  <Badge variant="outline">A 級</Badge>
                  <Badge
                    variant="secondary"
                    className="text-green-700 bg-green-100 dark:bg-green-900 dark:text-green-300"
                  >
                    95 分
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                  <Card>
                    <CardHeader className="flex flex-row justify-between items-center pb-2 space-y-0">
                      <CardTitle className="text-sm font-medium">平均處理時間</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">2.8 天</div>
                      <p className="text-xs text-muted-foreground">較團隊平均快 0.4 天</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row justify-between items-center pb-2 space-y-0">
                      <CardTitle className="text-sm font-medium">案件完成率</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">96.5%</div>
                      <p className="text-xs text-muted-foreground">較團隊平均高 4%</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row justify-between items-center pb-2 space-y-0">
                      <CardTitle className="text-sm font-medium">客戶滿意度</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">4.9/5</div>
                      <p className="text-xs text-muted-foreground">較團隊平均高 0.2</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row justify-between items-center pb-2 space-y-0">
                      <CardTitle className="text-sm font-medium">當前工作量</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">8 件</div>
                      <p className="text-xs text-muted-foreground">工作量適中</p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="team" className="space-y-4">
          <StaffPerformanceComparison />
        </TabsContent>
        <TabsContent value="trends" className="space-y-4">
          <StaffPerformanceChart />
        </TabsContent>
      </Tabs>
    </div>
  )
}
